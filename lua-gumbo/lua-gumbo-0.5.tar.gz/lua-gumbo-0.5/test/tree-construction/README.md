This is a snapshot of the `tree-construction` directory of the
[html5lib test suite], minus the `scripted` sub-directory, at commit
`515dc09aaa25d48a72f0d4c1a890507022b36e09`.

[html5lib test suite]: https://github.com/html5lib/html5lib-tests
